package com.pexe.encryption.model

import android.arch.persistence.room.Entity

@Entity
data class User (val userName: String, val password: String)