package com.pexe.encryption

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.pexe.encryption.model.User
import com.pexe.encryption.repository.AppDatabase
import retrofit2.Retrofit
import retrofit2.http.Headers
import retrofit2.http.POST

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
//
//        val retrofit = Retrofit.Builder()
//            .baseUrl("https://mobiuat.bancovotorantim.com.br/")
//            .build()
//
//        retrofit.create(TestService::class.java)


        val db = AppDatabase.getDatabase(this)

        val userTeste = User("daniel", "123456")
        db.userDAO().putUser(userTeste)

    }
}

interface TestService {

    @POST("apfv-base-proposta-comercial/adapters/AuthAdapter/login")
    fun login()

}