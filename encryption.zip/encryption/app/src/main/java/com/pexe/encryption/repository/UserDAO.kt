package com.pexe.encryption.repository

import android.arch.persistence.room.Dao
import android.arch.persistence.room.Delete
import android.arch.persistence.room.Insert
import android.arch.persistence.room.Query
import com.pexe.encryption.model.User

@Dao
interface UserDAO {

    @Query("select * from User")
    fun getUsers(): List<User>

    @Insert
    fun putUser(user: User)

    @Delete
    fun deleteUser(user: User)
}